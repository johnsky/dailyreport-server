class Unauthorized(Exception):
    pass
