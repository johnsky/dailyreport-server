VERSION = (0,3,1,'svn')
from fullhistory import register_model, get_active_histories, FullHistoryHandler
