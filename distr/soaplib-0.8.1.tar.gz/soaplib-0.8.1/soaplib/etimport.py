# only import lxml in this fork
import lxml.etree as ElementTree